/**
 * 
 */
/**
 * @author g4l1n
 *
 */
module SAE_Java {
	requires ardoise;
}